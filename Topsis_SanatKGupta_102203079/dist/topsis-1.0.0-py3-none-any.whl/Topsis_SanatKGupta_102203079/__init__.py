from main import validate_inputs
from main import topsis
