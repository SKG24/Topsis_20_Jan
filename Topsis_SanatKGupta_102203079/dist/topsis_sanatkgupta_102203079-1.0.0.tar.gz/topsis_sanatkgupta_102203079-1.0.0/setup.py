from setuptools import setup, find_packages

setup(
    name="topsis-sanatkgupta-102203079",                       # Package name
    version="1.0.0",                     # Version
    description="A Python library for TOPSIS implementation.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Sanat Kumar Gupta",
    author_email="gupta.sanat24@gmail.com",  # Replace with your email
    url="https://github.com/SKG24/Topsis_20_Jan",  # Replace with your GitHub repo
    packages=find_packages(),
    install_requires=[
        "pandas>=1.0.0",
        "numpy>=1.18.0",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)
